import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/hooks/use-auth";
import { motion } from "framer-motion";
import { Target, Timer, ArrowLeft, CheckCircle2, XCircle } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api";
import { useAction } from "convex/react";
import { useMutation } from "convex/react";

type Question = {
  id: number;
  type: "mcq" | "nat";
  question: string;
  options?: string[];
  answer?: number | string;
  marks?: number;
  topic?: string;
  explanation?: string;
};

const FALLBACK_QUESTIONS: Array<Question> = [
  {
    id: 1,
    type: "mcq",
    question: "Which of the following has the smallest asymptotic growth for large n?",
    options: ["n log n", "n^1.5", "n!", "2^n"],
    answer: 0,
    marks: 1,
    topic: "programming_and_dsa",
  },
  {
    id: 2,
    type: "mcq",
    question: "In a relational database, which normal form eliminates transitive dependency?",
    options: ["1NF", "2NF", "3NF", "BCNF"],
    answer: 2,
    marks: 1,
    topic: "database_management",
  },
  {
    id: 3,
    type: "nat",
    question:
      "Evaluate the worst-case time complexity exponent k for binary search: O(log n) = O(n^k). Enter k to 2 decimals.",
    answer: "0.00",
    marks: 1,
    topic: "theory_of_computation",
  },
];

export default function ExamSimPage() {
  const { user, isLoading } = useAuth();
  const navigate = useNavigate();
  const generateExam = useAction(api.ai.generateExam);
  const createAttempt = useMutation(api.exams.createAttempt);
  const submitAttempt = useMutation(api.exams.submitAttempt);
  const [attemptId, setAttemptId] = useState<string | null>(null);
  const initialTime = 60 * 180;

  const [timeLeft, setTimeLeft] = useState(initialTime); // 3 hours
  const [current, setCurrent] = useState(0);
  const [answers, setAnswers] = useState<Record<number, string | number>>({});
  const [questions, setQuestions] = useState<Array<Question>>(FALLBACK_QUESTIONS);
  const [loading, setLoading] = useState<boolean>(true);
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    let mounted = true;
    const load = async () => {
      try {
        setLoading(true);
        const generated = await generateExam({
          numQuestions: 65,
          difficulty: "mixed",
          includeExplanations: true,
        });
        if (!mounted) return;

        const parsed = Array.isArray(generated) ? generated : [];
        if (parsed.length > 0) {
          const qMapped = parsed.map((q: any, idx: number) => ({
            id: Number(q.id ?? idx + 1),
            type: q.type === "nat" ? "nat" : "mcq",
            question: String(q.question ?? "Untitled"),
            options: q.type === "mcq" ? (Array.isArray(q.options) ? q.options : ["A", "B", "C", "D"]) : undefined,
            answer: q.answer,
            marks: q.marks === 2 ? 2 : 1,
            topic: q.topic ? String(q.topic) : undefined,
            explanation: q.explanation ? String(q.explanation) : undefined,
          }));
          setQuestions(qMapped as Array<Question>);

          // Create attempt in backend
          try {
            const id = await createAttempt({ questions: qMapped as any });
            setAttemptId(id as unknown as string);
          } catch (e) {
            // Non-fatal; user can still practice
            console.error("Failed to create attempt:", e);
          }

          toast.success("AI mock test ready!");
        } else {
          toast.error("AI returned no questions. Using fallback.");
          setQuestions(FALLBACK_QUESTIONS);

          try {
            const id = await createAttempt({ questions: FALLBACK_QUESTIONS as any });
            setAttemptId(id as unknown as string);
          } catch (e) {
            console.error("Failed to create attempt:", e);
          }
        }
      } catch (e) {
        const msg = e instanceof Error ? e.message : "Unknown error";
        toast.error(`AI generation failed: ${msg}. Using fallback.`);
        setQuestions(FALLBACK_QUESTIONS);

        try {
          const id = await createAttempt({ questions: FALLBACK_QUESTIONS as any });
          setAttemptId(id as unknown as string);
        } catch (err) {
          console.error("Failed to create attempt:", err);
        }
      } finally {
        if (mounted) setLoading(false);
      }
    };
    load();
    return () => {
      mounted = false;
    };
  }, [generateExam, createAttempt]);

  useEffect(() => {
    if (loading) return;
    if (timeLeft <= 0) {
      handleSubmit();
      return;
    }
    timerRef.current = window.setTimeout(() => setTimeLeft((t) => t - 1), 1000);
    return () => {
      if (timerRef.current) window.clearTimeout(timerRef.current);
    };
  }, [timeLeft, loading]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#00FF80] flex items-center justify-center">
        <div className="text-black text-2xl font-bold">Loading...</div>
      </div>
    );
  }
  if (!user) {
    navigate("/auth");
    return null;
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-[#00FF80] p-4 flex items-center justify-center">
        <div className="bg-white border-4 border-black p-6 shadow-[8px_8px_0px_#000000] text-center">
          <div className="text-2xl font-black text-black mb-2">Generating AI Full Mock Test…</div>
          <div className="text-black font-bold opacity-80">This may take a few seconds</div>
        </div>
      </div>
    );
  }

  const q = questions[current];

  const formatTime = (s: number) => {
    const m = Math.floor(s / 60)
      .toString()
      .padStart(2, "0");
    const ss = (s % 60).toString().padStart(2, "0");
    return `${m}:${ss}`;
  };

  // Add progress percentage for UI
  const progressPercent =
    questions.length > 0 ? Math.round(((current + 1) / questions.length) * 100) : 0;

  const handleSubmit = async () => {
    // simple scoring for demo (local display)
    let score = 0;
    for (const qu of questions) {
      if (qu.type === "mcq") {
        if (answers[qu.id] === qu.answer) score += 1;
      } else {
        const userVal = Number(answers[qu.id]);
        const correct = Number(qu.answer);
        if (!Number.isNaN(userVal) && !Number.isNaN(correct) && Math.abs(userVal - correct) < 0.01) {
          score += 1;
        }
      }
    }

    // Submit to backend for storage + guidance
    try {
      const durationSec = initialTime - timeLeft;
      if (attemptId) {
        const res = await submitAttempt({
          attemptId: attemptId as any,
          answers: Object.fromEntries(Object.entries(answers).map(([k, v]) => [String(k), v as any])),
          durationSec,
        });
        toast.success(`Saved! Score: ${res.score}/${res.total}`);
        if (res.weakTopics?.length) {
          toast.message("Focus next", {
            description: res.weakTopics.map((t: string) => t.replace(/_/g, " ")).join(", "),
          });
        }
      } else {
        toast.message("Note", {
          description: "Could not save attempt (no attempt id). Score computed locally.",
        });
      }
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Unknown error";
      toast.error(`Failed to save attempt: ${msg}`);
    }

    // Navigate after brief delay to allow toasts to show
    setTimeout(() => navigate("/dashboard"), 800);
  };

  const handleAnswer = (value: string | number) => {
    setAnswers((a) => ({ ...a, [q.id]: value }));
  };

  return (
    <div className="min-h-screen bg-[#00FF80] p-4">
      <motion.div initial={{ y: -40, opacity: 0 }} animate={{ y: 0, opacity: 1 }} className="mb-4">
        <div className="bg-[#0080FF] border-4 border-black p-6 shadow-[8px_8px_0px_#000000] flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-black text-white tracking-tight">
              GATE CS EXAM SIMULATION
            </h1>
            <p className="text-white font-bold mt-2">
              Practice under realistic constraints
            </p>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={() => navigate("/dashboard")}
              className="bg-white text-black font-black border-4 border-black shadow-[4px_4px_0px_#000000]"
            >
              <ArrowLeft className="h-5 w-5 mr-2" />
              BACK
            </Button>
            <Button
              onClick={handleSubmit}
              className="bg-[#FF0080] hover:bg-[#CC0066] text-white font-black border-4 border-black shadow-[4px_4px_0px_#000000]"
            >
              SUBMIT
            </Button>
          </div>
        </div>
      </motion.div>

      {/* Top progress bar */}
      <div className="mb-6">
        <div className="w-full h-4 border-4 border-black bg-white shadow-[4px_4px_0px_#000000] relative overflow-hidden">
          <div
            className="h-full bg-[#FF0080] transition-all duration-500"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
        <div className="mt-2 text-black font-black text-sm">
          {current + 1} of {questions.length} ({progressPercent}%)
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <motion.div initial={{ x: -30, opacity: 0 }} animate={{ x: 0, opacity: 1 }} className="lg:col-span-2">
          <Card className="bg-white border-4 border-black shadow-[8px_8px_0px_#000000]">
            <CardHeader>
              <CardTitle className="text-black font-black text-xl flex items-center gap-2">
                <Target className="h-6 w-6" />
                Question {current + 1} / {questions.length}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 bg-[#FFFAF0] border-2 border-black font-bold text-black">
                {q.question}
              </div>
              {q.type === "mcq" ? (
                <div className="grid gap-3">
                  {q.options!.map((opt, idx) => {
                    const selected = answers[q.id] === idx;
                    return (
                      <button
                        key={idx}
                        onClick={() => handleAnswer(idx)}
                        className={`text-left p-3 border-2 border-black font-bold flex items-center justify-between transition-all duration-200 hover:translate-y-[-1px] hover:shadow-[3px_3px_0px_#000000] focus:outline-none ${
                          selected
                            ? "bg-[#00FF80] ring-4 ring-black/20"
                            : "bg-white hover:bg-[#F5F5F5]"
                        }`}
                      >
                        <span className="text-black">{opt}</span>
                        {selected ? (
                          <CheckCircle2 className="h-5 w-5 text-black" />
                        ) : (
                          <XCircle className="h-5 w-5 text-black opacity-30" />
                        )}
                      </button>
                    );
                  })}
                </div>
              ) : (
                <div className="grid gap-2">
                  <label className="text-black font-black text-sm">Enter Value</label>
                  <div className="flex items-center gap-2">
                    <Input
                      className="border-2 border-black font-bold bg-white focus-visible:ring-4 focus-visible:ring-black/20"
                      placeholder="e.g., 0.00"
                      value={(answers[q.id] as string | undefined) ?? ""}
                      onChange={(e) => handleAnswer(e.target.value)}
                    />
                    <span className="px-2 py-1 border-2 border-black bg-[#FFFAF0] text-black text-xs font-black">
                      NAT
                    </span>
                  </div>
                </div>
              )}

              {q.explanation ? (
                <div className="mt-2 p-3 border-2 border-black bg-white text-black text-sm font-bold">
                  Explanation: {q.explanation}
                </div>
              ) : null}

              <div className="flex justify-between pt-2">
                <Button
                  variant="outline"
                  className="bg-white border-4 border-black font-black shadow-[4px_4px_0px_#000000] hover:translate-y-[-1px] hover:shadow-[6px_6px_0px_#000000] transition-all"
                  onClick={() => setCurrent((c) => Math.max(0, c - 1))}
                  disabled={current === 0}
                >
                  Prev
                </Button>
                <Button
                  className="bg-[#0080FF] hover:bg-[#0060CC] text-white border-4 border-black font-black shadow-[4px_4px_0px_#000000] hover:translate-y-[-1px] hover:shadow-[6px_6px_0px_#000000] transition-all"
                  onClick={() =>
                    setCurrent((c) => Math.min(questions.length - 1, c + 1))
                  }
                  disabled={current === questions.length - 1}
                >
                  Next
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ x: 30, opacity: 0 }} animate={{ x: 0, opacity: 1 }}>
          <Card className="bg-yellow-400 border-4 border-black shadow-[8px_8px_0px_#000000] sticky top-4">
            <CardHeader>
              <CardTitle className="text-black font-black text-xl flex items-center gap-2">
                <Timer className="h-6 w-6" />
                TIME LEFT
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-5xl font-black text-black text-center">
                {formatTime(timeLeft)}
              </div>

              {/* Legend */}
              <div className="mt-4 flex items-center gap-2 text-xs font-black text-black">
                <span className="px-2 py-1 border-2 border-black bg-[#FF0080] text-white">Current</span>
                <span className="px-2 py-1 border-2 border-black bg-[#00FF80]">Answered</span>
                <span className="px-2 py-1 border-2 border-black bg-white">Unanswered</span>
              </div>

              <div className="mt-4 grid grid-cols-5 gap-2">
                {questions.map((item, idx) => {
                  const answered = answers[idx + 1] !== undefined;
                  return (
                    <button
                      key={idx}
                      onClick={() => setCurrent(idx)}
                      className={`p-2 border-2 border-black font-black transition-all duration-150 hover:translate-y-[-1px] hover:shadow-[2px_2px_0px_#000000] ${
                        current === idx
                          ? "bg-[#FF0080] text-white"
                          : answered
                          ? "bg-[#00FF80] text-black"
                          : "bg-white text-black"
                      }`}
                    >
                      {idx + 1}
                    </button>
                  );
                })}
              </div>

              {/* Submit CTA duplication for convenience on sidebar */}
              <div className="mt-4">
                <Button
                  onClick={handleSubmit}
                  className="w-full bg-[#FF0080] hover:bg-[#CC0066] text-white font-black border-4 border-black shadow-[4px_4px_0px_#000000] hover:translate-y-[-1px] hover:shadow-[6px_6px_0px_#000000] transition-all"
                >
                  Submit
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}