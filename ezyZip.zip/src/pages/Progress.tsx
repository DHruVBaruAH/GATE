import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { api } from "@/convex/_generated/api";
import { useQuery } from "convex/react";
import { motion } from "framer-motion";
import { BarChart3, Clock, Target, Trophy, ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router";

export default function ProgressPage() {
  const { user, isLoading } = useAuth();
  const navigate = useNavigate();

  const weekly = useQuery(api.progress.getWeeklyStats);
  const subjects = useQuery(api.progress.getUserProgress);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#0080FF] flex items-center justify-center">
        <div className="text-white text-2xl font-bold">Loading...</div>
      </div>
    );
  }
  if (!user) {
    navigate("/auth");
    return null;
  }

  const subjectHoursEntries = weekly?.subjectHours
    ? Object.entries(weekly.subjectHours as Record<string, number>)
    : [];

  return (
    <div className="min-h-screen bg-[#0080FF] p-4">
      <motion.div initial={{ y: -40, opacity: 0 }} animate={{ y: 0, opacity: 1 }} className="mb-6">
        <div className="bg-[#FF0080] border-4 border-black p-6 shadow-[8px_8px_0px_#000000] flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-black text-white tracking-tight">PROGRESS & ANALYTICS</h1>
            <p className="text-white font-bold mt-2">Track your grind. Optimize your wins.</p>
          </div>
          <Button
            variant="outline"
            onClick={() => navigate("/dashboard")}
            className="bg-white text-black font-black border-4 border-black shadow-[4px_4px_0px_#000000]"
          >
            <ArrowLeft className="h-5 w-5 mr-2" />
            BACK
          </Button>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}>
          <Card className="bg-[#00FF80] border-4 border-black shadow-[8px_8px_0px_#000000]">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-black font-black">
                <Clock className="h-6 w-6" />
                WEEKLY HOURS
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-black text-black">{(weekly?.totalHours ?? 0).toFixed(1)}h</div>
              <p className="text-black font-bold mt-1">Keep the pace!</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}>
          <Card className="bg-[#0080FF] border-4 border-black shadow-[8px_8px_0px_#000000]">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-white font-black">
                <Target className="h-6 w-6" />
                AVG FOCUS
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-black text-white">{(weekly?.avgFocusScore ?? 0).toFixed(0)}%</div>
              <p className="text-white font-bold mt-1">This week</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}>
          <Card className="bg-yellow-400 border-4 border-black shadow-[8px_8px_0px_#000000]">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-black font-black">
                <Trophy className="h-6 w-6" />
                SESSIONS
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-black text-black">{weekly?.sessionsCount ?? 0}</div>
              <p className="text-black font-bold mt-1">Completed this week</p>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <motion.div initial={{ y: 30, opacity: 0 }} animate={{ y: 0, opacity: 1 }}>
        <Card className="bg-white border-4 border-black shadow-[8px_8px_0px_#000000]">
          <CardHeader>
            <CardTitle className="text-black font-black text-2xl flex items-center gap-2">
              <BarChart3 className="h-7 w-7" />
              HOURS BY SUBJECT (WEEK)
            </CardTitle>
          </CardHeader>
          <CardContent>
            {subjectHoursEntries.length === 0 ? (
              <div className="p-4 border-2 border-dashed border-black text-black font-bold">
                No sessions this week yet. Time to grind.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {subjectHoursEntries.map(([key, hours]) => (
                  <div key={key} className="p-4 bg-gray-100 border-2 border-black">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-black text-black text-sm">{key.replace(/_/g, " ")}</span>
                      <span className="font-black text-black">{hours.toFixed(1)}h</span>
                    </div>
                    <div className="h-3 w-full border-2 border-black">
                      <div
                        className="h-full bg-[#FF0080]"
                        style={{ width: `${Math.min(100, (hours / 10) * 100)}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      <motion.div initial={{ y: 30, opacity: 0 }} animate={{ y: 0, opacity: 1 }} className="mt-6">
        <Card className="bg-white border-4 border-black shadow-[8px_8px_0px_#000000]">
          <CardHeader>
            <CardTitle className="text-black font-black text-2xl">SUBJECT PROGRESS</CardTitle>
          </CardHeader>
          <CardContent>
            {(subjects ?? []).length === 0 ? (
              <div className="p-4 border-2 border-dashed border-black text-black font-bold">
                No tracked progress yet. Complete sessions to populate this.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {(subjects ?? []).map((s) => (
                  <div key={s._id} className="p-4 bg-gray-100 border-2 border-black">
                    <div className="flex justify-between items-center mb-1">
                      <span className="font-black text-black text-sm">
                        {s.subject.replace(/_/g, " ")}
                      </span>
                      <span className="font-black text-black">
                        {s.topicsCompleted.length}/{s.totalTopics}
                      </span>
                    </div>
                    <div className="h-3 w-full border-2 border-black">
                      <div
                        className="h-full bg-[#0080FF]"
                        style={{
                          width: `${Math.min(100, (s.topicsCompleted.length / s.totalTopics) * 100)}%`,
                        }}
                      />
                    </div>
                    <div className="mt-2 text-xs text-black font-bold">
                      Avg Focus: {s.averageFocusScore.toFixed(0)}%
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}