import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useAuth } from "@/hooks/use-auth";
import { api } from "@/convex/_generated/api";
import { useQuery } from "convex/react";
import { motion } from "framer-motion";
import {
  Brain,
  Clock,
  Target,
  Trophy,
  Zap,
  BookOpen,
  BarChart3,
  Settings,
  Play,
  Timer,
  Menu,
  FileText,
  Loader2,
} from "lucide-react";
import { useNavigate } from "react-router";
import { useEffect, useState } from "react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";

// Auth gate wrapper to ensure stable hook order inside content
export default function Dashboard() {
  const { user, isLoading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isLoading && !user) {
      navigate("/auth");
    }
  }, [isLoading, user, navigate]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#FF0080] flex items-center justify-center">
        <div className="text-white text-2xl font-bold">Loading...</div>
      </div>
    );
  }
  if (!user) return null;

  return <DashboardContent user={user} />;
}

type ChecklistItem = { id: string; title: string; done: boolean };
type SubjectProgressData = { courseUrl: string; items: Array<ChecklistItem> };

function DashboardContent({ user }: { user: any }) {
  const navigate = useNavigate();

  // Convex queries are always called in this component, which only mounts after user is ready
  const progress = useQuery(api.progress.getUserProgress);
  const todaysSessions = useQuery(api.studySessions.getTodaysSessions);
  const weeklyStats = useQuery(api.progress.getWeeklyStats);

  const todaysMinutes = Array.isArray(todaysSessions)
    ? todaysSessions.reduce(
        (sum: number, session: any) => sum + (session?.duration || 0),
        0
      )
    : 0;
  const todaysHours = (todaysMinutes / 60) || 0;
  const studyStreak = user.studyStreak || 0;
  const level = user.level || 1;

  const SUBJECTS: Array<{ key: string; name: string; color: string }> = [
    { key: "programming_and_dsa", name: "Programming & DSA", color: "#FF0080" },
    { key: "database_management", name: "Database Management", color: "#00FF80" },
    { key: "operating_systems", name: "Operating Systems", color: "#0080FF" },
    { key: "computer_networks", name: "Computer Networks", color: "#FF8000" },
    { key: "theory_of_computation", name: "Theory of Computation", color: "#8000FF" },
    { key: "discrete_mathematics", name: "Discrete Mathematics", color: "#FF0040" },
  ];

  const STORAGE_KEY = "gate_cs_progress_v1";

  const [subjectData, setSubjectData] = useState<Record<string, SubjectProgressData>>({});
  const [manageOpen, setManageOpen] = useState(false);
  const [editingKey, setEditingKey] = useState<string | null>(null);
  const [newItemTitle, setNewItemTitle] = useState("");
  const [courseUrlInput, setCourseUrlInput] = useState("");
  const [navLoading, setNavLoading] = useState(false);
  const [exporting, setExporting] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === "object") {
          setSubjectData(parsed);
        }
      }
    } catch {
      // ignore parse errors
    }
  }, []);

  const persist = (next: Record<string, SubjectProgressData>) => {
    setSubjectData(next);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch {
      // quota or private mode
    }
  };

  const ensureSubject = (key: string) => {
    const current = subjectData[key];
    if (current) return current;
    return { courseUrl: "", items: [] };
  };

  const openManager = (key: string) => {
    const s = ensureSubject(key);
    setEditingKey(key);
    setCourseUrlInput(s.courseUrl || "");
    setNewItemTitle("");
    setManageOpen(true);
  };

  const addItem = () => {
    if (!editingKey) return;
    const title = newItemTitle.trim();
    if (!title) return;
    const s = ensureSubject(editingKey);
    const nextItems: Array<ChecklistItem> = [
      ...s.items,
      { id: crypto.randomUUID(), title, done: false },
    ];
    const next = { ...subjectData, [editingKey]: { ...s, items: nextItems } };
    persist(next);
    setNewItemTitle("");
  };

  const toggleItem = (itemId: string) => {
    if (!editingKey) return;
    const s = ensureSubject(editingKey);
    const nextItems = s.items.map((it) =>
      it.id === itemId ? { ...it, done: !it.done } : it
    );
    const next = { ...subjectData, [editingKey]: { ...s, items: nextItems } };
    persist(next);
  };

  const removeItem = (itemId: string) => {
    if (!editingKey) return;
    const s = ensureSubject(editingKey);
    const nextItems = s.items.filter((it) => it.id !== itemId);
    const next = { ...subjectData, [editingKey]: { ...s, items: nextItems } };
    persist(next);
  };

  const saveCourseUrl = () => {
    if (!editingKey) return;
    const s = ensureSubject(editingKey);
    const next = {
      ...subjectData,
      [editingKey]: { ...s, courseUrl: courseUrlInput.trim() },
    };
    persist(next);
  };

  const getPercent = (key: string) => {
    const s = subjectData[key];
    if (!s || s.items.length === 0) return 0;
    const done = s.items.filter((i) => i.done).length;
    return Math.round((done / s.items.length) * 100);
  };

  const handleExportPdf = () => {
    if (exporting) return;
    setExporting(true);
    try {
      window.print();
    } finally {
      // Best-effort reset; browsers don't provide a reliable print completion event
      setTimeout(() => setExporting(false), 1200);
    }
  };

  return (
    <div className="min-h-screen bg-[#FF0080] p-4 mx-auto max-w-7xl">
      {/* Header */}
      <motion.div
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="mb-8"
      >
        <div className="bg-[#00FF80] border-4 border-black p-6 shadow-[8px_8px_0px_#000000]">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-4xl font-black text-black tracking-tight">
                GATE CS 2026 PREP
              </h1>
              <p className="text-xl font-bold text-black mt-2">
                Welcome back, {user.name || "Study Warrior"}!
              </p>
            </div>

            {/* Desktop actions */}
            <div className="hidden md:flex gap-4">
              <Button
                onClick={() => {
                  if (navLoading) return;
                  setNavLoading(true);
                  navigate("/focus");
                }}
                disabled={navLoading}
                className="bg-[#0080FF] hover:bg-[#0060CC] text-white font-black text-lg px-8 py-4 border-4 border-black shadow-[4px_4px_0px_#000000] hover:shadow-[2px_2px_0px_#000000] transition-all"
              >
                {navLoading ? (
                  <Loader2 className="mr-2 h-6 w-6 animate-spin" />
                ) : (
                  <Play className="mr-2 h-6 w-6" />
                )}
                {navLoading ? "Loading..." : "START FOCUS"}
              </Button>

              <Dialog>
                <DialogTrigger asChild>
                  <Button
                    variant="outline"
                    className="bg-white hover:bg-gray-100 text-black font-black border-4 border-black shadow-[4px_4px_0px_#000000] hover:shadow-[2px_2px_0px_#000000] transition-all"
                  >
                    Help
                  </Button>
                </DialogTrigger>
                <DialogContent className="border-4 border-black p-0 overflow-hidden">
                  <motion.div
                    initial={{ opacity: 0, scale: 0.92, y: 12 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    transition={{ type: "spring", stiffness: 240, damping: 20 }}
                    className="bg-white"
                  >
                    <DialogHeader className="border-b-4 border-black p-4 bg-[#FF0080]">
                      <DialogTitle className="text-white font-black">
                        Quick Help
                      </DialogTitle>
                    </DialogHeader>
                    <div className="p-4 space-y-3">
                      <p className="text-black font-bold">
                        • Start a Pomodoro session from "START FOCUS"
                      </p>
                      <p className="text-black font-bold">
                        • Track analytics in the Progress section
                      </p>
                      <p className="text-black font-bold">
                        • Customize your preferences in Settings
                      </p>
                    </div>
                  </motion.div>
                </DialogContent>
              </Dialog>

              <Button
                onClick={() => {
                  if (navLoading) return;
                  setNavLoading(true);
                  navigate("/settings");
                }}
                disabled={navLoading}
                variant="outline"
                className="bg-white hover:bg-gray-100 text-black font-black border-4 border-black shadow-[4px_4px_0px_#000000] hover:shadow-[2px_2px_0px_#000000] transition-all"
              >
                {navLoading ? (
                  <Loader2 className="h-6 w-6 animate-spin" />
                ) : (
                  <Settings className="h-6 w-6" />
                )}
              </Button>
            </div>

            {/* Mobile menu */}
            <div className="md:hidden">
              <Sheet>
                <SheetTrigger asChild>
                  <Button
                    variant="outline"
                    className="bg-white hover:bg-gray-100 text-black font-black border-4 border-black shadow-[4px_4px_0px_#000000]"
                  >
                    <Menu className="h-6 w-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="border-l-4 border-black p-0">
                  <div className="bg-[#00FF80] border-b-4 border-black p-4">
                    <div className="text-2xl font-black text-black">MENU</div>
                  </div>
                  <div className="p-4 grid gap-3">
                    <Button
                      onClick={() => {
                        if (navLoading) return;
                        setNavLoading(true);
                        navigate("/focus");
                      }}
                      disabled={navLoading}
                      className="w-full bg-[#0080FF] hover:bg-[#0060CC] text-white font-black border-4 border-black shadow-[4px_4px_0px_#000000]"
                    >
                      {navLoading ? (
                        <>
                          <Loader2 className="mr-2 h-5 w-5 animate-spin" /> Loading…
                        </>
                      ) : (
                        <>
                          <Play className="mr-2 h-5 w-5" /> Start Focus
                        </>
                      )}
                    </Button>
                    <Button
                      onClick={() => {
                        if (navLoading) return;
                        setNavLoading(true);
                        navigate("/progress");
                      }}
                      disabled={navLoading}
                      className="w-full bg-white hover:bg-gray-100 text-black font-black border-4 border-black shadow-[4px_4px_0px_#000000]"
                    >
                      <BarChart3 className="mr-2 h-5 w-5" />
                      Progress
                    </Button>
                    <Button
                      onClick={() => {
                        if (navLoading) return;
                        setNavLoading(true);
                        navigate("/exam-sim");
                      }}
                      disabled={navLoading}
                      className="w-full bg-white hover:bg-gray-100 text-black font-black border-4 border-black shadow-[4px_4px_0px_#000000]"
                    >
                      <Target className="mr-2 h-5 w-5" />
                      Exam Simulation
                    </Button>
                    <Button
                      onClick={() => {
                        if (navLoading) return;
                        setNavLoading(true);
                        navigate("/settings");
                      }}
                      disabled={navLoading}
                      variant="outline"
                      className="w-full bg-white hover:bg-gray-100 text-black font-black border-4 border-black shadow-[4px_4px_0px_#000000]"
                    >
                      <Settings className="mr-2 h-5 w-5" />
                      Settings
                    </Button>

                    <Dialog>
                      <DialogTrigger asChild>
                        <Button
                          variant="outline"
                          className="w-full bg-white hover:bg-gray-100 text-black font-black border-4 border-black shadow-[4px_4px_0px_#000000]"
                        >
                          Help
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="border-4 border-black p-0 overflow-hidden">
                        <motion.div
                          initial={{ opacity: 0, scale: 0.92, y: 12 }}
                          animate={{ opacity: 1, scale: 1, y: 0 }}
                          transition={{ type: "spring", stiffness: 240, damping: 20 }}
                          className="bg-white"
                        >
                          <DialogHeader className="border-b-4 border-black p-4 bg-[#FF0080]">
                            <DialogTitle className="text-white font-black">
                              Quick Help
                            </DialogTitle>
                          </DialogHeader>
                          <div className="p-4 space-y-3">
                            <p className="text-black font-bold">
                              • Start Focus to begin a Pomodoro session
                            </p>
                            <p className="text-black font-bold">
                              • See analytics under Progress
                            </p>
                            <p className="text-black font-bold">
                              • Configure timers and preferences in Settings
                            </p>
                          </div>
                        </motion.div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="bg-[#00FF80] border-4 border-black shadow-[8px_8px_0px_#000000] hover:shadow-[4px_4px_0px_#000000] transition-all">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-black font-black">
                <Clock className="h-6 w-6" />
                TODAY'S HOURS
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-black text-black">
                {todaysHours.toFixed(1)}h
              </div>
              <p className="text-black font-bold mt-1">Keep grinding!</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="bg-[#0080FF] border-4 border-black shadow-[8px_8px_0px_#000000] hover:shadow-[4px_4px_0px_#000000] transition-all">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-white font-black">
                <Zap className="h-6 w-6" />
                STUDY STREAK
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-black text-white">
                {studyStreak} days
              </div>
              <p className="text-white font-bold mt-1">Unstoppable!</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="bg-yellow-400 border-4 border-black shadow-[8px_8px_0px_#000000] hover:shadow-[4px_4px_0px_#000000] transition-all">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-black font-black">
                <Trophy className="h-6 w-6" />
                LEVEL
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-black text-black">
                {level}
              </div>
              <Progress value={(user.experience || 0) % 100} className="mt-2" />
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.4 }}
        >
          <Card className="bg-red-400 border-4 border-black shadow-[8px_8px_0px_#000000] hover:shadow-[4px_4px_0px_#000000] transition-all">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-white font-black">
                <Brain className="h-6 w-6" />
                FOCUS SCORE
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-black text-white">
                {weeklyStats?.avgFocusScore?.toFixed(0) || 0}%
              </div>
              <p className="text-white font-bold mt-1">This week</p>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Quick Actions */}
      <motion.div
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8"
      >
        <Card
          className={`bg-white border-4 border-black shadow-[8px_8px_0px_#000000] hover:shadow-[4px_4px_0px_#000000] transition-all ${navLoading ? "opacity-60 pointer-events-none" : "cursor-pointer"}`}
          onClick={() => {
            if (navLoading) return;
            setNavLoading(true);
            navigate("/focus");
          }}
        >
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-black font-black text-xl">
              <Timer className="h-8 w-8" />
              POMODORO SESSION
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-black font-bold">
              Start a focused 25-minute study session
            </p>
          </CardContent>
        </Card>

        <Card
          className={`bg-white border-4 border-black shadow-[8px_8px_0px_#000000] hover:shadow-[4px_4px_0px_#000000] transition-all ${navLoading ? "opacity-60 pointer-events-none" : "cursor-pointer"}`}
          onClick={() => {
            if (navLoading) return;
            setNavLoading(true);
            navigate("/exam-sim");
          }}
        >
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-black font-black text-xl">
              <Target className="h-8 w-8" />
              EXAM SIMULATION
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-black font-bold">Practice with GATE CS interface</p>
          </CardContent>
        </Card>

        <Card
          className={`bg-white border-4 border-black shadow-[8px_8px_0px_#000000] hover:shadow-[4px_4px_0px_#000000] transition-all ${navLoading ? "opacity-60 pointer-events-none" : "cursor-pointer"}`}
          onClick={() => {
            if (navLoading) return;
            setNavLoading(true);
            navigate("/progress");
          }}
        >
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-black font-black text-xl">
              <BarChart3 className="h-8 w-8" />
              PROGRESS TRACKER
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-black font-bold">
              View detailed analytics & insights
            </p>
          </CardContent>
        </Card>

        <Card className="bg-white border-4 border-black shadow-[8px_8px_0px_#000000] hover:shadow-[4px_4px_0px_#000000] transition-all">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-black font-black text-xl">
              <FileText className="h-8 w-8" />
              GATE 2026 ROADMAP (PDF)
            </CardTitle>
          </CardHeader>
          <CardContent className="flex items-center justify-between">
            <p className="text-black font-bold">Open the study roadmap PDF</p>
            <a
              href="/assets/GATE_CSE_2026_RoadMap__2_.pdf"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex"
            >
              <Button className="bg-[#FF0080] hover:bg-[#CC0066] text-white font-black border-4 border-black shadow-[4px_4px_0px_#000000]">
                Open PDF
              </Button>
            </a>
          </CardContent>
        </Card>
      </motion.div>

      {/* Subject Progress (Dynamic with localStorage) */}
      <motion.div initial={{ y: 50, opacity: 0 }} animate={{ y: 0, opacity: 1 }}>
        <Card className="bg-white border-4 border-black shadow-[8px_8px_0px_#000000]">
          <CardHeader className="flex flex-col md:flex-row md:items-center md:justify-between">
            <CardTitle className="text-black font-black text-2xl flex items-center gap-2">
              <BookOpen className="h-8 w-8" />
              GATE CS SYLLABUS PROGRESS
            </CardTitle>
            <div className="mt-3 md:mt-0">
              <Button
                onClick={handleExportPdf}
                disabled={exporting}
                className="bg-[#FF0080] hover:bg-[#CC0066] text-white font-black border-4 border-black shadow-[4px_4px_0px_#000000]"
              >
                {exporting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Exporting…
                  </>
                ) : (
                  "Export PDF"
                )}
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {SUBJECTS.map((s) => {
                const percent = getPercent(s.key);
                const url = subjectData[s.key]?.courseUrl || "";
                return (
                  <div
                    key={s.key}
                    className="p-4 bg-gray-100 border-2 border-black"
                  >
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-black text-black text-sm">
                        {s.name}
                      </span>
                      <span className="font-black text-black">{percent}%</span>
                    </div>
                    <div className="h-3 w-full border-2 border-black">
                      <div
                        className="h-full"
                        style={{
                          width: `${percent}%`,
                          backgroundColor: s.color,
                        }}
                      />
                    </div>
                    <div className="mt-3 flex items-center justify-between gap-2">
                      <a
                        href={url || "#"}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex"
                        onClick={(e) => {
                          if (!url) e.preventDefault();
                        }}
                      >
                        <Button
                          className="bg-[#0080FF] hover:bg-[#0060CC] text-white font-black border-4 border-black shadow-[4px_4px_0px_#000000]"
                          variant="outline"
                          disabled={!url}
                        >
                          Open Course
                        </Button>
                      </a>
                      <Button
                        variant="outline"
                        onClick={() => openManager(s.key)}
                        className="bg-white hover:bg-gray-100 text-black font-black border-4 border-black shadow-[4px_4px_0px_#000000]"
                      >
                        Track
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Manage Subject Dialog */}
      <Dialog open={manageOpen} onOpenChange={setManageOpen}>
        <DialogContent className="border-4 border-black p-0 overflow-hidden">
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ type: "spring", stiffness: 240, damping: 20 }}
            className="bg-white"
          >
            <DialogHeader className="border-b-4 border-black p-4 bg-[#00FF80]">
              <DialogTitle className="text-black font-black">
                Manage {SUBJECTS.find((x) => x.key === editingKey)?.name || "Subject"}
              </DialogTitle>
            </DialogHeader>

            <div className="p-4 space-y-4">
              <div className="grid gap-2">
                <div className="text-black font-black text-sm">
                  Course URL (YouTube playlist or course)
                </div>
                <div className="flex gap-2">
                  <Input
                    className="border-2 border-black font-bold"
                    placeholder="https://youtube.com/playlist?..."
                    value={courseUrlInput}
                    onChange={(e) => setCourseUrlInput(e.target.value)}
                  />
                  <Button
                    onClick={saveCourseUrl}
                    className="bg-[#FF0080] hover:bg-[#CC0066] text-white font-black border-4 border-black shadow-[4px_4px_0px_#000000]"
                  >
                    Save
                  </Button>
                </div>
              </div>

              <div className="grid gap-2">
                <div className="text-black font-black text-sm">
                  Checklist (topics/videos)
                </div>
                <div className="flex gap-2">
                  <Input
                    className="border-2 border-black font-bold"
                    placeholder="Add topic/video title"
                    value={newItemTitle}
                    onChange={(e) => setNewItemTitle(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        addItem();
                      }
                    }}
                  />
                  <Button
                    onClick={addItem}
                    className="bg-[#0080FF] hover:bg-[#0060CC] text-white font-black border-4 border-black shadow-[4px_4px_0px_#000000]"
                  >
                    Add
                  </Button>
                </div>

                <div className="max-h-72 overflow-auto border-2 border-black p-2 bg-[#FFFAF0]">
                  {(editingKey ? ensureSubject(editingKey).items : []).length === 0 ? (
                    <div className="text-black font-bold">
                      No items yet. Add topics/videos to track.
                    </div>
                  ) : (
                    <div className="grid gap-2">
                      {(editingKey ? ensureSubject(editingKey).items : []).map((it) => (
                        <div
                          key={it.id}
                          className="flex items-center justify-between p-2 bg-white border-2 border-black"
                        >
                          <label className="flex items-center gap-2 text-black font-bold">
                            <input
                              type="checkbox"
                              checked={it.done}
                              onChange={() => toggleItem(it.id)}
                            />
                            <span className={it.done ? "line-through opacity-70" : ""}>
                              {it.title}
                            </span>
                          </label>
                          <Button
                            variant="outline"
                            onClick={() => removeItem(it.id)}
                            className="bg-white hover:bg-gray-100 text-black font-black border-2 border-black h-8 px-3"
                          >
                            Remove
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              <div className="flex justify-end">
                <Button
                  onClick={() => setManageOpen(false)}
                  variant="outline"
                  className="bg-white hover:bg-gray-100 text-black font-black border-4 border-black shadow-[4px_4px_0px_#000000]"
                >
                  Close
                </Button>
              </div>
            </div>
          </motion.div>
        </DialogContent>
      </Dialog>
    </div>
  );
}