import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useAuth } from "@/hooks/use-auth";
import { api } from "@/convex/_generated/api";
import { useMutation } from "convex/react";
import { motion } from "framer-motion";
import { Settings, Save, ArrowLeft } from "lucide-react";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { toast } from "sonner";

export default function SettingsPage() {
  const { user, isLoading } = useAuth();
  const navigate = useNavigate();
  const updatePreferences = useMutation(api.users.updatePreferences);

  const [theme, setTheme] = useState("light");
  const [soundscape, setSoundscape] = useState("none");
  const [pomodoroLength, setPomodoroLength] = useState(25);
  const [shortBreak, setShortBreak] = useState(5);
  const [longBreak, setLongBreak] = useState(15);
  const [focusMonitoring, setFocusMonitoring] = useState(false);

  useEffect(() => {
    if (user?.preferences) {
      setTheme(user.preferences.theme);
      setSoundscape(user.preferences.soundscape);
      setPomodoroLength(user.preferences.pomodoroLength);
      setShortBreak(user.preferences.shortBreak);
      setLongBreak(user.preferences.longBreak);
      setFocusMonitoring(user.preferences.focusMonitoring);
    }
  }, [user?.preferences]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#FF0080] flex items-center justify-center">
        <div className="text-white text-2xl font-bold">Loading...</div>
      </div>
    );
  }
  if (!user) {
    navigate("/auth");
    return null;
  }

  const handleSave = async () => {
    try {
      await updatePreferences({
        theme,
        soundscape,
        pomodoroLength,
        shortBreak,
        longBreak,
        focusMonitoring,
      });
      toast.success("Preferences saved!");
    } catch {
      toast.error("Failed to save preferences");
    }
  };

  return (
    <div className="min-h-screen bg-[#FF0080] p-4">
      <motion.div initial={{ y: -40, opacity: 0 }} animate={{ y: 0, opacity: 1 }} className="mb-6">
        <div className="bg-[#00FF80] border-4 border-black p-6 shadow-[8px_8px_0px_#000000] flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-black text-black tracking-tight">SETTINGS</h1>
            <p className="text-black font-bold mt-2">Tune your focus environment</p>
          </div>
          <Button
            variant="outline"
            onClick={() => navigate("/dashboard")}
            className="bg-white text-black font-black border-4 border-black shadow-[4px_4px_0px_#000000]"
          >
            <ArrowLeft className="h-5 w-5 mr-2" />
            BACK
          </Button>
        </div>
      </motion.div>

      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        <Card className="bg-white border-4 border-black shadow-[8px_8px_0px_#000000]">
          <CardHeader>
            <CardTitle className="text-black font-black text-xl flex items-center gap-2">
              <Settings className="h-6 w-6" />
              Preferences
            </CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="grid gap-2">
              <Label className="text-black font-black">Theme</Label>
              <Select value={theme} onValueChange={setTheme}>
                <SelectTrigger className="border-2 border-black font-bold">
                  <SelectValue placeholder="Select theme" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="light">Light</SelectItem>
                  <SelectItem value="dark">Dark</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-2">
              <Label className="text-black font-black">Soundscape</Label>
              <Select value={soundscape} onValueChange={setSoundscape}>
                <SelectTrigger className="border-2 border-black font-bold">
                  <SelectValue placeholder="Select soundscape" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  <SelectItem value="rain">Rain</SelectItem>
                  <SelectItem value="lofi">Lo-fi</SelectItem>
                  <SelectItem value="forest">Forest</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-2">
              <Label className="text-black font-black">Pomodoro Length (min)</Label>
              <Input
                type="number"
                className="border-2 border-black font-bold"
                value={pomodoroLength}
                onChange={(e) => setPomodoroLength(Math.max(1, Number(e.target.value || 25)))}
              />
            </div>

            <div className="grid gap-2">
              <Label className="text-black font-black">Short Break (min)</Label>
              <Input
                type="number"
                className="border-2 border-black font-bold"
                value={shortBreak}
                onChange={(e) => setShortBreak(Math.max(1, Number(e.target.value || 5)))}
              />
            </div>

            <div className="grid gap-2">
              <Label className="text-black font-black">Long Break (min)</Label>
              <Input
                type="number"
                className="border-2 border-black font-bold"
                value={longBreak}
                onChange={(e) => setLongBreak(Math.max(1, Number(e.target.value || 15)))}
              />
            </div>

            <div className="flex items-center justify-between p-3 border-2 border-black bg-[#FFFAF0]">
              <div>
                <div className="text-black font-black">Focus Monitoring</div>
                <div className="text-black/70 text-sm font-bold">Enable webcam-based focus meter</div>
              </div>
              <Switch checked={focusMonitoring} onCheckedChange={(v) => setFocusMonitoring(!!v)} />
            </div>

            <div className="md:col-span-2 flex justify-end">
              <Button
                onClick={handleSave}
                className="bg-[#0080FF] hover:bg-[#0060CC] text-white font-black border-4 border-black shadow-[4px_4px_0px_#000000]"
              >
                <Save className="h-5 w-5 mr-2" />
                Save Preferences
              </Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
