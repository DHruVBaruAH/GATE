import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { motion } from "framer-motion";
import { 
  Brain, 
  Target, 
  Zap, 
  Timer, 
  Trophy, 
  BookOpen,
  Shield,
  BarChart3,
  Play,
  ArrowRight,
  CheckCircle,
  Star
} from "lucide-react";
import { useNavigate } from "react-router";
import { api } from "@/convex/_generated/api";
import { useMutation, useQuery } from "convex/react";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { Trash2 } from "lucide-react";
import { useState } from "react";

export default function Landing() {
  const { isAuthenticated, isLoading } = useAuth();
  const navigate = useNavigate();

  const blocked = useQuery(api.distractions.listBlocked);
  const addBlocked = useMutation(api.distractions.addBlocked);
  const toggleBlocked = useMutation(api.distractions.toggleBlockedActive);
  const removeBlocked = useMutation(api.distractions.removeBlocked);

  const [blockUrl, setBlockUrl] = useState("");
  const [blockCategory, setBlockCategory] = useState("general");

  const handleAddBlock = async () => {
    const url = blockUrl.trim();
    if (!url) {
      toast.error("Enter a website to block");
      return;
    }
    try {
      await addBlocked({ url, category: blockCategory });
      toast.success("Added to Distraction Control");
      setBlockUrl("");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to add");
    }
  };

  const handleGetStarted = () => {
    if (isAuthenticated) {
      navigate("/dashboard");
    } else {
      navigate("/auth");
    }
  };

  return (
    <div className="min-h-screen bg-[#FF0080] overflow-x-hidden">
      {/* Hero Section */}
      <motion.section
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="relative min-h-screen flex items-center justify-center p-4"
      >
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="grid grid-cols-8 gap-4 h-full">
            {Array.from({ length: 64 }).map((_, i) => (
              <motion.div
                key={i}
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: i * 0.01 }}
                className="bg-black"
              />
            ))}
          </div>
        </div>

        <div className="relative z-10 max-w-6xl mx-auto text-center">
          {/* Logo */}
          <motion.div
            initial={{ y: -100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, type: "spring" }}
            className="mb-8"
          >
            <div className="inline-block bg-[#00FF80] p-6 border-4 border-black shadow-[12px_12px_0px_#000000]">
              <Brain className="h-16 w-16 text-black" />
            </div>
          </motion.div>

          {/* Main Headline */}
          <motion.h1
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.8 }}
            className="text-6xl md:text-8xl font-black text-white mb-6 tracking-tight leading-none"
            style={{ fontFamily: 'Space Grotesk, sans-serif' }}
          >
            GATE CS
            <br />
            <span className="text-[#00FF80]">2026</span>
            <br />
            DOMINATION
          </motion.h1>

          {/* Subtitle */}
          <motion.p
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.4, duration: 0.8 }}
            className="text-2xl md:text-3xl font-bold text-white mb-12 max-w-4xl mx-auto"
          >
            The ultimate distraction-free study sanctuary that transforms you into a GATE CS warrior through AI-powered focus, gamification, and brutal efficiency.
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.6, duration: 0.8 }}
            className="flex flex-col sm:flex-row gap-6 justify-center items-center"
          >
            <Button
              onClick={handleGetStarted}
              className="bg-[#0080FF] hover:bg-[#0060CC] text-white font-black text-2xl px-12 py-6 border-4 border-black shadow-[8px_8px_0px_#000000] hover:shadow-[4px_4px_0px_#000000] transition-all transform hover:translate-x-1 hover:translate-y-1"
              disabled={isLoading}
            >
              <Play className="mr-3 h-8 w-8" />
              {isAuthenticated ? "GO TO DASHBOARD" : "START GRINDING"}
              <ArrowRight className="ml-3 h-8 w-8" />
            </Button>

            <Button
              onClick={() => document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' })}
              variant="outline"
              className="bg-white hover:bg-gray-100 text-black font-black text-xl px-8 py-6 border-4 border-black shadow-[8px_8px_0px_#000000] hover:shadow-[4px_4px_0px_#000000] transition-all"
            >
              SEE FEATURES
            </Button>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.8, duration: 0.8 }}
            className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto"
          >
            {[
              { number: "100%", label: "DISTRACTION FREE" },
              { number: "AI", label: "POWERED COACHING" },
              { number: "24/7", label: "FOCUS TRACKING" }
            ].map((stat, index) => (
              <div key={index} className="bg-[#00FF80] border-4 border-black p-6 shadow-[8px_8px_0px_#000000]">
                <div className="text-4xl font-black text-black">{stat.number}</div>
                <div className="text-lg font-bold text-black">{stat.label}</div>
              </div>
            ))}
          </motion.div>
        </div>
      </motion.section>

      {/* Features Section */}
      <section id="features" className="py-20 px-4 bg-[#00FF80]">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl md:text-6xl font-black text-black mb-6 tracking-tight">
              BRUTAL FEATURES
            </h2>
            <p className="text-2xl font-bold text-black max-w-3xl mx-auto">
              Every tool you need to crush GATE CS 2026 and eliminate distractions forever
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: Shield,
                title: "DISTRACTION BLOCKER",
                description: "Nuclear-level website/app blocking with emergency exceptions only",
                color: "#FF0080"
              },
              {
                icon: Timer,
                title: "ADAPTIVE POMODORO",
                description: "AI adjusts your session times based on focus patterns",
                color: "#0080FF"
              },
              {
                icon: Brain,
                title: "FOCUS MONITORING",
                description: "Real-time webcam & typing pattern analysis for peak concentration",
                color: "#FF8000"
              },
              {
                icon: Target,
                title: "EXAM SIMULATION",
                description: "Perfect replica of GATE CS interface for realistic practice",
                color: "#8000FF"
              },
              {
                icon: Trophy,
                title: "GAMIFICATION",
                description: "Level up your study avatar with streaks, badges, and leaderboards",
                color: "#00FF80"
              },
              {
                icon: BarChart3,
                title: "ANALYTICS BEAST",
                description: "Detailed insights on focus quality, weak topics, and performance trends",
                color: "#FF0040"
              }
            ].map((feature, index) => (
              <motion.div
                key={index}
                initial={{ scale: 0.8, opacity: 0 }}
                whileInView={{ scale: 1, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.05 }}
                className="group cursor-pointer"
              >
                <Card className="bg-white border-4 border-black shadow-[8px_8px_0px_#000000] group-hover:shadow-[12px_12px_0px_#000000] transition-all h-full">
                  <CardHeader>
                    <div 
                      className="w-16 h-16 border-4 border-black flex items-center justify-center mb-4"
                      style={{ backgroundColor: feature.color }}
                    >
                      <feature.icon className="h-8 w-8 text-white" />
                    </div>
                    <CardTitle className="text-xl font-black text-black">
                      {feature.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-black font-bold">
                      {feature.description}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Syllabus Section */}
      <section className="py-20 px-4 bg-[#0080FF]">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl md:text-6xl font-black text-white mb-6 tracking-tight">
              COMPLETE SYLLABUS
            </h2>
            <p className="text-2xl font-bold text-white max-w-3xl mx-auto">
              Every GATE CS topic tracked, analyzed, and optimized for maximum efficiency
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              "Programming & DSA",
              "Database Management", 
              "Operating Systems",
              "Computer Networks",
              "Computer Organization",
              "Theory of Computation",
              "Compiler Design",
              "Discrete Mathematics",
              "Linear Algebra",
              "Probability & Statistics",
              "General Aptitude",
              "Engineering Mathematics"
            ].map((subject, index) => (
              <motion.div
                key={index}
                initial={{ x: -50, opacity: 0 }}
                whileInView={{ x: 0, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.05 }}
                className="bg-[#00FF80] border-4 border-black p-4 shadow-[4px_4px_0px_#000000] hover:shadow-[8px_8px_0px_#000000] transition-all"
              >
                <div className="flex items-center gap-3">
                  <CheckCircle className="h-6 w-6 text-black flex-shrink-0" />
                  <span className="font-black text-black text-sm">{subject}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-black">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            whileInView={{ scale: 1, opacity: 1 }}
            viewport={{ once: true }}
          >
            <h2 className="text-5xl md:text-6xl font-black text-white mb-8 tracking-tight">
              READY TO
              <br />
              <span className="text-[#FF0080]">DOMINATE</span>
              <br />
              GATE CS 2026?
            </h2>
            
            <div className="flex items-center justify-center gap-4 mb-8">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} className="h-8 w-8 text-[#00FF80] fill-current" />
              ))}
            </div>

            <p className="text-xl font-bold text-white mb-12 max-w-2xl mx-auto">
              Join thousands of students who've already started their journey to GATE CS success. 
              No distractions. No excuses. Just pure, focused preparation.
            </p>

            <Button
              onClick={handleGetStarted}
              className="bg-[#FF0080] hover:bg-[#CC0066] text-white font-black text-3xl px-16 py-8 border-4 border-white shadow-[12px_12px_0px_#00FF80] hover:shadow-[8px_8px_0px_#00FF80] transition-all transform hover:translate-x-1 hover:translate-y-1"
              disabled={isLoading}
            >
              <Zap className="mr-4 h-10 w-10" />
              {isAuthenticated ? "CONTINUE GRINDING" : "START NOW - FREE"}
              <ArrowRight className="ml-4 h-10 w-10" />
            </Button>
          </motion.div>
        </div>
      </section>

      {/* Distraction Control Section */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            className="text-center mb-10"
          >
            <h2 className="text-5xl md:text-6xl font-black text-black mb-4 tracking-tight">
              DISTRACTION CONTROL
            </h2>
            <p className="text-xl font-bold text-black max-w-3xl mx-auto">
              Maintain your focus. Manage blocked sites directly here.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <motion.div
              initial={{ x: -30, opacity: 0 }}
              whileInView={{ x: 0, opacity: 1 }}
              viewport={{ once: true }}
              className="lg:col-span-1 bg-[#00FF80] border-4 border-black p-6 shadow-[8px_8px_0px_#000000]"
            >
              <h3 className="text-2xl font-black text-black mb-4">Add Website</h3>
              <div className="space-y-3">
                <div className="grid gap-2">
                  <label className="font-bold text-black text-sm">Website URL</label>
                  <Input
                    placeholder="e.g. youtube.com"
                    value={blockUrl}
                    onChange={(e) => setBlockUrl(e.target.value)}
                    className="border-2 border-black font-bold"
                  />
                </div>
                <div className="grid gap-2">
                  <label className="font-bold text-black text-sm">Category</label>
                  <Input
                    placeholder="general, social, video, etc."
                    value={blockCategory}
                    onChange={(e) => setBlockCategory(e.target.value || "general")}
                    className="border-2 border-black font-bold"
                  />
                </div>
                <Button
                  onClick={handleAddBlock}
                  className="w-full bg-[#0080FF] hover:bg-[#0060CC] text-white font-black border-4 border-black shadow-[4px_4px_0px_#000000]"
                >
                  Add to Blocklist
                </Button>
                <p className="text-xs font-bold text-black/80">
                  Tip: For best results, combine this with system-level or extension blockers.
                </p>
              </div>
            </motion.div>

            <motion.div
              initial={{ x: 30, opacity: 0 }}
              whileInView={{ x: 0, opacity: 1 }}
              viewport={{ once: true }}
              className="lg:col-span-2 bg-white border-4 border-black p-6 shadow-[8px_8px_0px_#000000]"
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-2xl font-black text-black">Your Blocklist</h3>
                <span className="text-black font-bold">
                  {blocked ? blocked.length : 0} sites
                </span>
              </div>

              <div className="space-y-3 max-h-[360px] overflow-auto pr-2">
                {(blocked ?? []).length === 0 ? (
                  <div className="p-4 border-2 border-dashed border-black text-black font-bold">
                    No sites yet. Add your top distractions to start controlling them.
                  </div>
                ) : (
                  (blocked ?? []).map((item) => (
                    <div
                      key={item._id}
                      className="flex items-center justify-between p-3 border-2 border-black bg-[#FFFAF0]"
                    >
                      <div className="min-w-0">
                        <div className="font-black text-black truncate">{item.url}</div>
                        <div className="text-sm font-bold text-black/70">
                          {item.category} • {item.isActive ? "Active" : "Inactive"}
                        </div>
                      </div>
                      <div className="flex items-center gap-3 flex-shrink-0">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold text-black">Block</span>
                          <Switch
                            checked={!!item.isActive}
                            onCheckedChange={async (val) => {
                              try {
                                await toggleBlocked({ id: item._id, isActive: !!val });
                                toast.success(val ? "Blocking enabled" : "Blocking disabled");
                              } catch {
                                toast.error("Failed to update");
                              }
                            }}
                          />
                        </div>
                        <Button
                          variant="outline"
                          className="bg-white border-2 border-black"
                          onClick={async () => {
                            try {
                              await removeBlocked({ id: item._id });
                              toast.success("Removed");
                            } catch {
                              toast.error("Failed to remove");
                            }
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#FF0080] border-t-4 border-black py-8 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <p className="text-white font-bold text-lg">
            Built for GATE CS warriors by{" "}
            <a
              href="https://vly.ai"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#00FF80] underline hover:text-white transition-colors font-black"
            >
              vly.ai
            </a>
          </p>
          <p className="text-white font-bold mt-2">
            © 2024 GATE CS Domination. Crush the competition.
          </p>
        </div>
      </footer>
    </div>
  );
}