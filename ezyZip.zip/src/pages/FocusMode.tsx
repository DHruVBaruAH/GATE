import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/hooks/use-auth";
import { api } from "@/convex/_generated/api";
import { useMutation } from "convex/react";
import { motion } from "framer-motion";
import { 
  Play, 
  Pause, 
  Square, 
  Volume2, 
  VolumeX, 
  Eye, 
  EyeOff,
  Timer,
  Brain,
  Target,
  Zap
} from "lucide-react";
import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router";
import { Id } from "@/convex/_generated/dataModel";
import { toast } from "sonner";

export default function FocusMode() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [isActive, setIsActive] = useState(false);
  const [timeLeft, setTimeLeft] = useState(25 * 60); // 25 minutes in seconds
  const [sessionType, setSessionType] = useState<"pomodoro" | "free" | "exam_simulation">("pomodoro");
  const [subject, setSubject] = useState("");
  const [topic, setTopic] = useState("");
  const [focusScore, setFocusScore] = useState(85);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [monitoringEnabled, setMonitoringEnabled] = useState(false);
  const [currentSessionId, setCurrentSessionId] = useState<Id<"studySessions"> | null>(null);
  
  const startSession = useMutation(api.studySessions.startSession);
  const endSession = useMutation(api.studySessions.endSession);
  
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (isActive && timeLeft > 0) {
      intervalRef.current = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            handleSessionComplete();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isActive, timeLeft]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleStart = async () => {
    if (!subject || !topic) {
      toast.error("Please select subject and topic first!");
      return;
    }

    try {
      const sessionId = await startSession({
        subject: subject as any,
        topic,
        sessionType,
      });
      setCurrentSessionId(sessionId);
      setIsActive(true);
      toast.success("Focus session started! 🎯");
    } catch (error) {
      toast.error("Failed to start session");
    }
  };

  const handlePause = () => {
    setIsActive(false);
    toast("Session paused");
  };

  const handleStop = async () => {
    if (currentSessionId) {
      try {
        await endSession({
          sessionId: currentSessionId,
          focusScore,
        });
        toast.success("Session completed! 🏆");
      } catch (error) {
        toast.error("Failed to save session");
      }
    }
    setIsActive(false);
    setTimeLeft(25 * 60);
    setCurrentSessionId(null);
  };

  const handleSessionComplete = async () => {
    if (currentSessionId) {
      try {
        await endSession({
          sessionId: currentSessionId,
          focusScore,
        });
        toast.success("🎉 Session completed! Great work!");
      } catch (error) {
        toast.error("Failed to save session");
      }
    }
    setIsActive(false);
    setCurrentSessionId(null);
    
    // Play completion sound
    if (soundEnabled) {
      const audio = new Audio('/notification.mp3');
      audio.play().catch(() => {});
    }
  };

  const startWebcamMonitoring = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setMonitoringEnabled(true);
    } catch (error) {
      toast.error("Camera access denied");
    }
  };

  const stopWebcamMonitoring = () => {
    if (videoRef.current?.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
    }
    setMonitoringEnabled(false);
  };

  if (!user) {
    navigate("/auth");
    return null;
  }

  return (
    <div className="min-h-screen bg-[#0080FF] p-4">
      {/* Header */}
      <motion.div
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="mb-8"
      >
        <div className="bg-[#FF0080] border-4 border-black p-6 shadow-[8px_8px_0px_#000000]">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-4xl font-black text-white tracking-tight">
                FOCUS MODE
              </h1>
              <p className="text-xl font-bold text-white mt-2">
                Lock in and eliminate distractions
              </p>
            </div>
            <Button
              onClick={() => navigate("/dashboard")}
              variant="outline"
              className="bg-white hover:bg-gray-100 text-black font-black border-4 border-black shadow-[4px_4px_0px_#000000]"
            >
              BACK TO DASHBOARD
            </Button>
          </div>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Timer Section */}
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.1 }}
          className="lg:col-span-2"
        >
          <Card className="bg-[#00FF80] border-4 border-black shadow-[8px_8px_0px_#000000] h-full">
            <CardHeader>
              <CardTitle className="text-black font-black text-3xl text-center">
                STUDY TIMER
              </CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col items-center justify-center space-y-8">
              {/* Giant Timer Display */}
              <div className="text-8xl font-black text-black tracking-wider">
                {formatTime(timeLeft)}
              </div>

              {/* Progress Ring */}
              <div className="relative w-48 h-48">
                <svg className="w-48 h-48 transform -rotate-90">
                  <circle
                    cx="96"
                    cy="96"
                    r="88"
                    stroke="black"
                    strokeWidth="8"
                    fill="transparent"
                    className="opacity-20"
                  />
                  <circle
                    cx="96"
                    cy="96"
                    r="88"
                    stroke="black"
                    strokeWidth="8"
                    fill="transparent"
                    strokeDasharray={`${2 * Math.PI * 88}`}
                    strokeDashoffset={`${2 * Math.PI * 88 * (timeLeft / (25 * 60))}`}
                    className="transition-all duration-1000"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <Timer className="h-16 w-16 text-black" />
                </div>
              </div>

              {/* Control Buttons */}
              <div className="flex gap-4">
                {!isActive ? (
                  <Button
                    onClick={handleStart}
                    className="bg-[#FF0080] hover:bg-[#CC0066] text-white font-black text-xl px-8 py-4 border-4 border-black shadow-[4px_4px_0px_#000000]"
                    disabled={!subject || !topic}
                  >
                    <Play className="mr-2 h-6 w-6" />
                    START
                  </Button>
                ) : (
                  <Button
                    onClick={handlePause}
                    className="bg-yellow-400 hover:bg-yellow-500 text-black font-black text-xl px-8 py-4 border-4 border-black shadow-[4px_4px_0px_#000000]"
                  >
                    <Pause className="mr-2 h-6 w-6" />
                    PAUSE
                  </Button>
                )}
                
                <Button
                  onClick={handleStop}
                  className="bg-red-500 hover:bg-red-600 text-white font-black text-xl px-8 py-4 border-4 border-black shadow-[4px_4px_0px_#000000]"
                >
                  <Square className="mr-2 h-6 w-6" />
                  STOP
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Controls & Settings */}
        <motion.div
          initial={{ x: 50, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="space-y-6"
        >
          {/* Session Setup */}
          <Card className="bg-white border-4 border-black shadow-[8px_8px_0px_#000000]">
            <CardHeader>
              <CardTitle className="text-black font-black text-xl">
                SESSION SETUP
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-black font-black text-sm mb-2 block">
                  SESSION TYPE
                </label>
                <Select value={sessionType} onValueChange={(value: any) => setSessionType(value)}>
                  <SelectTrigger className="border-2 border-black font-bold">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pomodoro">Pomodoro (25 min)</SelectItem>
                    <SelectItem value="free">Free Study</SelectItem>
                    <SelectItem value="exam_simulation">Exam Simulation</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-black font-black text-sm mb-2 block">
                  SUBJECT
                </label>
                <Select value={subject} onValueChange={setSubject}>
                  <SelectTrigger className="border-2 border-black font-bold">
                    <SelectValue placeholder="Select subject" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="programming">Programming & DSA</SelectItem>
                    <SelectItem value="database_management">Database Management</SelectItem>
                    <SelectItem value="operating_systems">Operating Systems</SelectItem>
                    <SelectItem value="computer_networks">Computer Networks</SelectItem>
                    <SelectItem value="theory_of_computation">Theory of Computation</SelectItem>
                    <SelectItem value="discrete_mathematics">Discrete Mathematics</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-black font-black text-sm mb-2 block">
                  TOPIC
                </label>
                <Input
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  placeholder="Enter specific topic"
                  className="border-2 border-black font-bold"
                />
              </div>
            </CardContent>
          </Card>

          {/* Focus Monitoring */}
          <Card className="bg-yellow-400 border-4 border-black shadow-[8px_8px_0px_#000000]">
            <CardHeader>
              <CardTitle className="text-black font-black text-xl flex items-center gap-2">
                <Brain className="h-6 w-6" />
                FOCUS METER
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center mb-4">
                <div className="text-4xl font-black text-black">
                  {focusScore}%
                </div>
                <p className="text-black font-bold">Current Focus Level</p>
              </div>
              
              <div className="flex justify-center gap-2 mb-4">
                <Button
                  onClick={monitoringEnabled ? stopWebcamMonitoring : startWebcamMonitoring}
                  variant="outline"
                  className="bg-white border-2 border-black font-bold"
                >
                  {monitoringEnabled ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  {monitoringEnabled ? "Stop" : "Start"} Monitoring
                </Button>
                
                <Button
                  onClick={() => setSoundEnabled(!soundEnabled)}
                  variant="outline"
                  className="bg-white border-2 border-black font-bold"
                >
                  {soundEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
                </Button>
              </div>

              {monitoringEnabled && (
                <video
                  ref={videoRef}
                  autoPlay
                  muted
                  className="w-full h-32 border-2 border-black object-cover"
                />
              )}
            </CardContent>
          </Card>

          {/* Quick Stats */}
          <Card className="bg-red-400 border-4 border-black shadow-[8px_8px_0px_#000000]">
            <CardHeader>
              <CardTitle className="text-white font-black text-xl flex items-center gap-2">
                <Zap className="h-6 w-6" />
                TODAY'S STATS
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-white font-bold">Sessions:</span>
                  <span className="text-white font-black">3</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-white font-bold">Hours:</span>
                  <span className="text-white font-black">2.5h</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-white font-bold">Avg Focus:</span>
                  <span className="text-white font-black">87%</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
